import LoginForm from '@/components/admin/LoginForm';

export default function AdminLoginPage() {
  return <LoginForm />;
}
