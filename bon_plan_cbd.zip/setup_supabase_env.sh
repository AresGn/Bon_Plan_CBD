#!/bin/bash

echo "DATABASE_URL=\"postgresql://postgres:11Silvere%40@db.dupbzoolphysyeykondk.supabase.co:5432/postgres\"" > .env.local
echo "Fichier .env.local généré avec la connexion Supabase (mot de passe encodé)." 